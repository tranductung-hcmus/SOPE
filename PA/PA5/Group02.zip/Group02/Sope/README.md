@copyright by Sope 2024
